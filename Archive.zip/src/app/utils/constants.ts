export const iconColors = {
  primary: "#0047ba",
  secondary: "#42464b",
};
