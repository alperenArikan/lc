import React from "react";
import { iconColors } from "../../../utils/constants";

const CartIcon: React.FC<{
  color?: "primary" | "secondary";
  className?: string;
}> = ({ color = "primary", className }) => {
  return (
    <span className={className}>
      <svg
        id="shopping_bag_black_24dp"
        xmlns="http://www.w3.org/2000/svg"
        width="32"
        height="32"
        viewBox="0 0 32 32"
      >
        <rect
          id="Rectangle_4519"
          data-name="Rectangle 4519"
          width="32"
          height="32"
          fill="none"
        />
        <path
          id="Path_10558"
          data-name="Path 10558"
          d="M25,7.6H22A5.809,5.809,0,0,0,16,2a5.809,5.809,0,0,0-6,5.6H7a2.914,2.914,0,0,0-3,2.8V27.2A2.914,2.914,0,0,0,7,30H25a2.914,2.914,0,0,0,3-2.8V10.4A2.914,2.914,0,0,0,25,7.6ZM16,4.8a2.914,2.914,0,0,1,3,2.8H13A2.914,2.914,0,0,1,16,4.8Zm9,22.4H7V10.4h3v2.8a1.5,1.5,0,0,0,3,0V10.4h6v2.8a1.5,1.5,0,0,0,3,0V10.4h3Z"
          fill={iconColors[color]}
        />
      </svg>
    </span>
  );
};

export default CartIcon;
