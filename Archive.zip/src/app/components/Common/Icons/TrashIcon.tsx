import React from "react";
import { iconColors } from "../../../utils/constants";

const TrashIcon: React.FC<{
  className?: string;
}> = ({ className }) => {
  return (
    <span className={className}>
      <svg
        id="delete_outline-black-18dp"
        xmlns="http://www.w3.org/2000/svg"
        width="32"
        height="32"
        viewBox="0 0 32 32"
      >
        <path
          id="Path_10555"
          data-name="Path 10555"
          d="M0,0H32V32H0Z"
          fill="none"
        />
        <path
          id="Path_10556"
          data-name="Path 10556"
          d="M6.571,26.111A3.033,3.033,0,0,0,9.714,29H22.286a3.033,3.033,0,0,0,3.143-2.889V8.778H6.571ZM9.714,11.667H22.286V26.111H9.714ZM21.5,4.444,19.929,3H12.071L10.5,4.444H5V7.333H27V4.444Z"
          transform="translate(0 0)"
          fill="#42464b"
        />
      </svg>
    </span>
  );
};

export default TrashIcon;
